中文版本请见[docs/zh_CN/CONTRIBUTING.md](docs/zh_CN/CONTRIBUTING.md)

## Thank you
Feel free to **create and issue** or to **make a pull request**. It truly helps us to improve.  

If this software do help you, you can consider to support us. Thanks a lot.  
* Paypal: https://www.paypal.me/KLsz  
* Alipay or WeChat:

![http://klsztx.nos-eastchina1.126.net/Alipay.jpg](http://klsztx.nos-eastchina1.126.net/Alipay.jpg) | ![http://klsztx.nos-eastchina1.126.net/WeChat.png](http://klsztx.nos-eastchina1.126.net/WeChat.png)
:--: | :--:

Thanks.  
