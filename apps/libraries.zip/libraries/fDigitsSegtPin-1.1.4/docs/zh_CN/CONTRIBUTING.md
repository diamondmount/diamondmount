## 首先感谢您能帮助我们
我们欢迎意见和建议，您可以通过**issue**和**pull request**表达您的想法。  

如果这款软件的确帮上了您的忙，您也可以考虑捐赠我们：  
* Paypal： https://www.paypal.me/KLsz
* 支付宝或微信：

![http://klsztx.nos-eastchina1.126.net/Alipay.jpg](http://klsztx.nos-eastchina1.126.net/Alipay.jpg) | ![http://klsztx.nos-eastchina1.126.net/WeChat.png](http://klsztx.nos-eastchina1.126.net/WeChat.png)
:--: | :--:

谢谢。  
