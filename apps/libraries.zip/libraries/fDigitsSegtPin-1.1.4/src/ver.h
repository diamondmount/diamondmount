/* fDigitsSegtPin by KLsz
 * For more info please visit "https://github.com/KuangLei" or "https://coding.net/u/KLsz"
 * License: GPL v3, CopyLeft KLsz
 */

#ifndef __VER_H__
#define __VER_H__

#define __FDIGITSSEGTPIN_VER__ "1.1.4"
#define __FDIGITSSEGTPIN_INFO__ "fDigitsSegtPin 1.1.4 by KLsz"
#define __FDIGITSSEGTPIN_LICENSE__ "License: GPL v3, CopyLeft KLsz"

#endif //__VER_H__
